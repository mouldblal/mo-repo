# Changelog

See: https://github.com/lgeiger/ide-python/releases
