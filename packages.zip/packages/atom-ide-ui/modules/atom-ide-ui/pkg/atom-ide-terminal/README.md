# Nuclide Terminal

This defines a terminal window that gives mosh-like access over nuclide-rpc to the remote server where the project is located.
